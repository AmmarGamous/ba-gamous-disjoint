# ERWEITERUNG_TESTNOTIZEN

## Getestete Erweiterungen

- `shortest_path`
- `clustered_random_center`
- `complete_graph`

## Geänderte Dateien

- `src/routing_algorithms.py`
- `src/failures.py`
- `src/experiment.py`
- `pipeline.py`
- `gui.py`
- `evaluation/result_analysis.py`
- `tests/test_extensions.py`
- `config/extension_test.json`
- `ERWEITERUNG_TESTNOTIZEN.md`

## Shortest Path

### Umsetzung

- `route_shortest_path(...)` ist in `src/routing_algorithms.py` ergänzt.
- `shortest_path` ist in `EXTRA_ALGORITHM_RUNNERS` registriert.
- `ALGORITHMS` enthält den Zusatzalgorithmus automatisch über `BASE_ALGORITHMS + tuple(EXTRA_ALGORITHM_RUNNERS)`.
- GUI-Label und Plot-Label/Farbe sind eingetragen.

### Tests

- `shortest_path` wird von `run_algorithms(...)` akzeptiert.
- Verbundener Graph liefert `success=True`.
- Durch ausgefallene Kanten getrennter Graph liefert `success=False`.
- Bei Erfolg entspricht `hops` der Anzahl der Routenkanten.
- Ausgefallene Kanten werden nicht verwendet.

## Clustered Random Center

### Umsetzung

- `clustered_random_center` ist in `FAILURE_MODEL_SPECS` registriert.
- `choose_random_cluster_center(...)` nutzt den übergebenen `rng`.
- Link-Failures wählen einen zufälligen Mittelpunkt und verwenden danach die vorhandene Clustered-Link-Logik.
- Node-Failures wählen einen zufälligen Mittelpunkt und verwenden `clustered_node_failures_around_center(...)`.
- Bei Node-Failures werden `source`, `destination` und der zufällige Mittelpunkt geschützt.
- `pipeline.py` kennt `clustered_random_center_link` und `clustered_random_center_node`.
- `gui.py` enthält die sichtbaren Labels.

### Tests

- Metadaten aus `failure_model_spec("clustered_random_center")` stimmen.
- Der Mittelpunkt ist weder `source` noch `destination`.
- Derselbe RNG-Seed wählt denselben Mittelpunkt.
- Die Pipeline akzeptiert beide neuen Failure-Kombinationen.
- Link-Variante liefert Kanten und keine ausgefallenen Knoten.
- Node-Variante liefert ausgefallene Knoten.
- `source`, `destination` und Mittelpunkt fallen bei Node-Failures nicht aus.
- `node_failures_to_edges(...)` erzeugt die betroffenen Kanten.
- CSV-Dateinamen verwenden den Präfix `clustered_random_center`.
- Das bestehende `clustered`-Modell wird weiterhin akzeptiert.

## Vollständiger Graph

### Umsetzung

- `complete_graph` ist über `_create_complete_graph(...)` in `src/experiment.py` vorhanden.
- `GRAPH_BUILDERS`, `GRAPH_PARAMETER_SPECS` und `GRAPH_VALIDATORS` enthalten `complete_graph`.
- `GRAPH_TYPES` wird weiterhin automatisch aus `GRAPH_BUILDERS` gebildet.
- `choose_endpoints(...)` enthält den Fallback für Graphen ohne nicht direkt benachbarte Paare.
- `pipeline.py` musste für `complete_graph` nicht geändert werden, weil es `experiment.GRAPH_TYPES`, `graph_parameter_from_dataset(...)` und `validate_graph_parameters(...)` nutzt.
- `gui.py` enthält `build_gui_complete_graph_dataset(...)` und einen eigenen GUI-Zweig für `complete_graph`.
- `config/extension_test.json` enthält einen kleinen Complete-Graph-Testlauf mit `runs=5`.

### Tests

- `complete_graph` ist in `GRAPH_BUILDERS`, `GRAPH_PARAMETER_SPECS`, `GRAPH_VALIDATORS` und `GRAPH_TYPES` registriert.
- `create_graph("complete_graph", 5, "", seed)` erzeugt 5 Knoten und 10 Kanten.
- Jeder Knoten ist mit jedem anderen verbunden.
- `choose_endpoints(...)` liefert im vollständigen Graphen zwei verschiedene, direkt benachbarte Knoten.
- Ein Graph ohne gültiges Knotenpaar löst `NetworkXNoPath` aus.
- `graph_parameter_from_dataset(...)` braucht keinen zusätzlichen Graphparameter.
- `validate_graph_parameters(...)` akzeptiert die Complete-Graph-Konfiguration.
- `build_gui_complete_graph_dataset(...)` erzeugt die erwartete Dataset-Struktur.
- Erdős-Rényi- und Random-Regular-Graphen funktionieren weiterhin.

