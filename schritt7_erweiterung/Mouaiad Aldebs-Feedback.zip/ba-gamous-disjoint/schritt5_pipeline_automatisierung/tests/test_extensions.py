"""Unit-Tests fuer die Shortest-Path-Erweiterung."""

from pathlib import Path
import random
import sys
import unittest

import networkx as nx


PIPELINE_ROOT = Path(__file__).resolve().parents[1]
STEP5_SRC = PIPELINE_ROOT / "src"
for import_path in (PIPELINE_ROOT, STEP5_SRC):
    if str(import_path) not in sys.path:
        sys.path.insert(0, str(import_path))

import gui

pipeline = gui.pipeline
failures = pipeline.failures
experiment = pipeline.experiment
run_algorithms = pipeline.routing_algorithms.run_algorithms


class ShortestPathExtensionTest(unittest.TestCase):
    """Prueft die minimale Erweiterung um `shortest_path`."""

    def test_shortest_path_is_accepted_by_run_algorithms(self):
        graph = nx.path_graph(4)

        results = run_algorithms(
            graph,
            0,
            3,
            failures=[],
            algorithms=["shortest_path"],
        )

        self.assertEqual(len(results), 1)
        self.assertEqual(results[0].algorithm, "shortest_path")

    def test_shortest_path_succeeds_on_connected_graph(self):
        graph = nx.path_graph(4)

        result = run_algorithms(
            graph,
            0,
            3,
            failures=[],
            algorithms=["shortest_path"],
        )[0]

        self.assertTrue(result.success)

    def test_shortest_path_fails_when_failures_disconnect_graph(self):
        graph = nx.path_graph(4)

        result = run_algorithms(
            graph,
            0,
            3,
            failures=[(1, 2)],
            algorithms=["shortest_path"],
        )[0]

        self.assertFalse(result.success)
        self.assertEqual(result.hops, -1)
        self.assertEqual(result.route, [])

    def test_successful_shortest_path_hops_match_route_edges(self):
        graph = nx.path_graph(4)

        result = run_algorithms(
            graph,
            0,
            3,
            failures=[],
            algorithms=["shortest_path"],
        )[0]

        self.assertTrue(result.success)
        self.assertEqual(result.hops, len(result.route))

    def test_shortest_path_does_not_use_failed_edges(self):
        graph = nx.Graph()
        graph.add_edges_from([(0, 1), (1, 3), (0, 2), (2, 3)])
        failures = [(0, 1)]

        result = run_algorithms(
            graph,
            0,
            3,
            failures=failures,
            algorithms=["shortest_path"],
        )[0]

        failed_edges = {frozenset(edge) for edge in failures}
        route_edges = {frozenset(edge) for edge in result.route}
        self.assertTrue(result.success)
        self.assertFalse(route_edges & failed_edges)


class ClusteredRandomCenterExtensionTest(unittest.TestCase):
    """Prueft das Failure-Modell `clustered_random_center`."""

    def test_clustered_random_center_metadata(self):
        spec = failures.failure_model_spec("clustered_random_center")

        self.assertEqual(spec["parameter"], "failure_start")
        self.assertEqual(spec["csv_prefix"], "clustered_random_center")
        self.assertFalse(spec["uses_failure_count"])
        self.assertTrue(spec["uses_cluster_parameters"])

    def test_random_cluster_center_is_not_source_or_destination(self):
        graph = nx.complete_graph(8)

        center = failures.choose_random_cluster_center(
            graph, 0, 7, random.Random(123)
        )

        self.assertNotIn(center, (0, 7))

    def test_random_cluster_center_is_reproducible_with_same_seed(self):
        graph = nx.complete_graph(8)

        first = failures.choose_random_cluster_center(
            graph, 0, 7, random.Random(123)
        )
        second = failures.choose_random_cluster_center(
            graph, 0, 7, random.Random(123)
        )

        self.assertEqual(first, second)

    def test_pipeline_accepts_clustered_random_center_link(self):
        selected = pipeline.selected_failures(
            {"failures": ["clustered_random_center_link"]}
        )

        self.assertEqual(
            selected,
            [("clustered_random_center_link", ("clustered_random_center", "link"))],
        )

    def test_pipeline_accepts_clustered_random_center_node(self):
        selected = pipeline.selected_failures(
            {"failures": ["clustered_random_center_node"]}
        )

        self.assertEqual(
            selected,
            [("clustered_random_center_node", ("clustered_random_center", "node"))],
        )

    def test_clustered_random_center_link_returns_edges_only(self):
        graph = nx.complete_graph(8)

        edges, nodes = failures.select_failures(
            graph,
            0,
            7,
            "link",
            "clustered_random_center",
            0,
            1.0,
            0.3,
            random.Random(123),
        )

        self.assertTrue(edges)
        self.assertEqual(nodes, [])

    def test_clustered_random_center_node_returns_nodes(self):
        graph = nx.complete_graph(8)

        _, nodes = failures.select_failures(
            graph,
            0,
            7,
            "node",
            "clustered_random_center",
            0,
            1.0,
            0.3,
            random.Random(123),
        )

        self.assertTrue(nodes)

    def test_clustered_random_center_node_protects_source_and_destination(self):
        graph = nx.complete_graph(8)

        _, nodes = failures.select_failures(
            graph,
            0,
            7,
            "node",
            "clustered_random_center",
            0,
            1.0,
            0.3,
            random.Random(123),
        )

        self.assertNotIn(0, nodes)
        self.assertNotIn(7, nodes)

    def test_clustered_random_center_node_protects_center(self):
        graph = nx.complete_graph(8)
        seed = 123
        center = failures.choose_random_cluster_center(
            graph, 0, 7, random.Random(seed)
        )

        _, nodes = failures.select_failures(
            graph,
            0,
            7,
            "node",
            "clustered_random_center",
            0,
            1.0,
            0.3,
            random.Random(seed),
        )

        self.assertNotIn(center, nodes)

    def test_clustered_random_center_node_edges_match_failed_nodes(self):
        graph = nx.complete_graph(8)

        edges, nodes = failures.select_failures(
            graph,
            0,
            7,
            "node",
            "clustered_random_center",
            0,
            1.0,
            0.3,
            random.Random(123),
        )

        expected = {frozenset(edge) for node in nodes for edge in graph.edges(node)}
        actual = {frozenset(edge) for edge in edges}
        self.assertEqual(actual, expected)

    def test_clustered_random_center_configuration_filename_uses_prefix(self):
        filename = experiment.configuration_filename(
            {
                "failure_type": "node",
                "failure_model": "clustered_random_center",
                "failure_start": 0.3,
            },
            0.3,
        )

        self.assertEqual(
            filename,
            "algorithms_clustered_random_center_node_fs0.3_fd0.3.csv",
        )

    def test_existing_clustered_model_is_still_accepted(self):
        selected = pipeline.selected_failures(
            {"failures": ["clustered_link", "clustered_node"]}
        )

        self.assertEqual(
            selected,
            [
                ("clustered_link", ("clustered", "link")),
                ("clustered_node", ("clustered", "node")),
            ],
        )


class CompleteGraphExtensionTest(unittest.TestCase):
    """Prueft die Erweiterung um `complete_graph`."""

    def test_complete_graph_is_registered_in_graph_builders(self):
        self.assertIn("complete_graph", experiment.GRAPH_BUILDERS)

    def test_complete_graph_is_registered_in_parameter_specs(self):
        self.assertEqual(
            experiment.GRAPH_PARAMETER_SPECS["complete_graph"],
            {"config_key": None, "cast": str},
        )

    def test_complete_graph_is_registered_in_graph_validators(self):
        self.assertIn("complete_graph", experiment.GRAPH_VALIDATORS)

    def test_complete_graph_is_in_graph_types(self):
        self.assertIn("complete_graph", experiment.GRAPH_TYPES)

    def test_create_complete_graph_has_requested_node_count(self):
        graph = experiment.create_graph("complete_graph", 5, "", seed=123)

        self.assertEqual(graph.number_of_nodes(), 5)

    def test_create_complete_graph_has_all_edges(self):
        graph = experiment.create_graph("complete_graph", 5, "", seed=123)

        self.assertEqual(graph.number_of_edges(), 10)

    def test_create_complete_graph_connects_every_node_pair(self):
        graph = experiment.create_graph("complete_graph", 5, "", seed=123)

        for first in graph.nodes:
            for second in graph.nodes:
                if first != second:
                    self.assertTrue(graph.has_edge(first, second))

    def test_choose_endpoints_returns_distinct_nodes_for_complete_graph(self):
        graph = nx.complete_graph(5)

        source, destination = experiment.choose_endpoints(
            graph, random.Random(123)
        )

        self.assertNotEqual(source, destination)

    def test_choose_endpoints_uses_fallback_adjacent_pair_for_complete_graph(self):
        graph = nx.complete_graph(5)

        source, destination = experiment.choose_endpoints(
            graph, random.Random(123)
        )

        self.assertTrue(graph.has_edge(source, destination))

    def test_choose_endpoints_raises_when_no_valid_pair_exists(self):
        graph = nx.Graph()
        graph.add_node(0)

        with self.assertRaises(nx.NetworkXNoPath):
            experiment.choose_endpoints(graph, random.Random(123))

    def test_complete_graph_parameter_from_dataset_needs_no_extra_parameter(self):
        dataset = {
            "name": "complete_n5",
            "type": "synthetic",
            "graph_type": "complete_graph",
            "nodes": 5,
        }

        self.assertEqual(experiment.graph_parameter_from_dataset(dataset), "")

    def test_complete_graph_validation_accepts_valid_configuration(self):
        experiment.validate_graph_parameters("complete_graph", 5, "", "complete_n5")

    def test_build_gui_complete_graph_dataset_uses_expected_structure(self):
        dataset = gui.build_gui_complete_graph_dataset(
            5,
            [1.0, 2.0],
            [0.3, 0.6],
            0.2,
        )

        self.assertEqual(
            dataset,
            {
                "name": "complete_n5",
                "display_name": "VollstÃ¤ndiger Graph n=5",
                "type": "synthetic",
                "graph_type": "complete_graph",
                "nodes": 5,
                "fail_factors": [1.0, 2.0],
                "failure_starts": [0.3, 0.6],
                "failure_drop": 0.2,
            },
        )

    def test_existing_erdos_renyi_graph_still_works(self):
        graph = experiment.create_graph("erdos_renyi", 5, 0.5, seed=123)

        self.assertEqual(graph.number_of_nodes(), 5)

    def test_existing_random_regular_graph_still_works(self):
        graph = experiment.create_graph("random_regular", 6, 2, seed=123)

        self.assertEqual(graph.number_of_nodes(), 6)
        self.assertTrue(all(degree == 2 for _, degree in graph.degree()))


if __name__ == "__main__":
    unittest.main()
