#!/usr/bin/env bash
set -euo pipefail
STEP5_ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
cd "$STEP5_ROOT"
python pipeline.py --config Output/test4_server/gui_config.json
