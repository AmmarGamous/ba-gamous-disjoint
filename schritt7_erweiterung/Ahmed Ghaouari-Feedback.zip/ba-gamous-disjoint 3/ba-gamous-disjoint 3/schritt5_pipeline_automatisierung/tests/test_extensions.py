"""Unit-Tests für die Schritt-7-Erweiterungen.

Geprüft werden die drei Beispiele aus `ERWEITERUNG.txt`:
Zusatzalgorithmus `shortest_path`, Fehlermodell `clustered_random_center`
und Graph-Typ `complete_graph`.
"""

import json
from pathlib import Path
import random
import sys
import tempfile
import unittest

import networkx as nx


PIPELINE_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PIPELINE_ROOT))

import pipeline

experiment = pipeline.experiment
failures = pipeline.failures
routing_algorithms = pipeline.routing_algorithms
result_analysis = pipeline.result_analysis
import gui


class ShortestPathAlgorithmTest(unittest.TestCase):
    """Prüft den Zusatzalgorithmus `shortest_path`."""

    def test_algorithm_is_registered_without_touching_base_algorithms(self):
        """Der Zusatzalgorithmus erweitert die Auswahl, ersetzt sie aber nicht."""
        self.assertIn("shortest_path", routing_algorithms.ALGORITHMS)
        self.assertNotIn("shortest_path", routing_algorithms.BASE_ALGORITHMS)
        self.assertEqual(len(routing_algorithms.BASE_ALGORITHMS), 6)

    def test_run_algorithms_accepts_the_new_algorithm(self):
        """`run_algorithms` akzeptiert den Algorithmus ohne Pfadcache."""
        graph = nx.path_graph(5)

        results = routing_algorithms.run_algorithms(
            graph, 0, 4, [], algorithms=["shortest_path"]
        )

        self.assertEqual(len(results), 1)
        self.assertEqual(results[0].algorithm, "shortest_path")

    def test_connected_graph_yields_success_and_matching_hops(self):
        """Ohne Ausfälle liefert der Algorithmus den kürzesten Weg."""
        graph = nx.path_graph(5)

        result = routing_algorithms.route_shortest_path(graph, 0, 4, [])

        self.assertTrue(result.success)
        self.assertEqual(result.hops, 4)
        self.assertEqual(result.route[0], (0, 1))

    def test_disconnected_graph_yields_failure(self):
        """Trennt ein Ausfall s von d, ist das Ergebnis ein Misserfolg."""
        graph = nx.path_graph(3)

        result = routing_algorithms.route_shortest_path(graph, 0, 2, [(1, 2)])

        self.assertFalse(result.success)
        self.assertEqual(result.hops, -1)
        self.assertEqual(result.route, [])

    def test_failures_do_not_modify_the_input_graph(self):
        """Der Algorithmus arbeitet auf einer Kopie des Graphen."""
        graph = nx.path_graph(3)

        routing_algorithms.route_shortest_path(graph, 0, 2, [(1, 2)])

        self.assertTrue(graph.has_edge(1, 2))

    def test_plot_label_and_color_exist(self):
        """Ohne Label und Farbe würde die Plot-Erzeugung abbrechen."""
        self.assertIn("shortest_path", result_analysis.ALGORITHM_LABELS)
        self.assertIn("shortest_path", result_analysis.ALGORITHM_COLORS)
        self.assertIn("shortest_path", gui.ALGORITHM_LABELS)

    def test_csv_rows_mark_the_algorithm_as_custom_structure(self):
        """Die Long-CSV bleibt für Zusatzalgorithmen befüllbar."""
        graph = nx.cycle_graph(6)

        rows = experiment.create_instance_rows(
            1, graph, 0, 3, [], "link", "random", algorithms=["shortest_path"]
        )

        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]["pathType"], "shortest_path")
        self.assertEqual(rows[0]["structureType"], "custom")
        self.assertEqual(rows[0]["stretch"], 0)


class ClusteredRandomCenterFailureTest(unittest.TestCase):
    """Prüft das Fehlermodell `clustered_random_center`."""

    def test_model_spec_uses_cluster_parameters(self):
        """Das Modell nutzt failureStart/failureDrop und einen eigenen Präfix."""
        self.assertTrue(failures.uses_cluster_parameters("clustered_random_center"))
        self.assertFalse(failures.uses_failure_count("clustered_random_center"))
        self.assertEqual(
            failures.failure_parameter_key("clustered_random_center"),
            "failure_start",
        )
        self.assertEqual(
            failures.failure_model_csv_prefix("clustered_random_center"),
            "clustered_random_center",
        )

    def test_random_center_is_never_source_or_destination(self):
        """Der Mittelpunkt liegt immer außerhalb des s-d-Paares."""
        graph = nx.complete_graph(6)
        rng = random.Random(1)

        centers = {
            failures.choose_random_cluster_center(graph, 0, 5, rng)
            for _ in range(50)
        }

        self.assertTrue(centers)
        self.assertNotIn(0, centers)
        self.assertNotIn(5, centers)

    def test_node_failures_protect_source_and_destination(self):
        """s und d fallen auch bei hohem failureStart nicht aus."""
        graph = nx.erdos_renyi_graph(20, 0.3, seed=7)
        rng = random.Random(3)

        _, failed_nodes = failures.select_failures(
            graph, 0, 19, "node", "clustered_random_center", 0, 0.9, 0.3, rng
        )

        self.assertNotIn(0, failed_nodes)
        self.assertNotIn(19, failed_nodes)

    def test_link_failures_are_edges_of_the_graph(self):
        """Alle ausgefallenen Kanten stammen aus dem Graphen."""
        graph = nx.erdos_renyi_graph(20, 0.3, seed=11)
        rng = random.Random(5)

        failed_edges, failed_nodes = failures.select_failures(
            graph, 0, 19, "link", "clustered_random_center", 0, 0.9, 0.3, rng
        )

        self.assertEqual(failed_nodes, [])
        for edge in failed_edges:
            self.assertTrue(graph.has_edge(*edge))

    def test_same_seed_reproduces_the_same_failures(self):
        """Gleicher RNG-Zustand erzeugt identische Ausfälle."""
        graph = nx.erdos_renyi_graph(20, 0.3, seed=13)

        first, _ = failures.select_failures(
            graph, 0, 19, "link", "clustered_random_center", 0, 0.6, 0.3,
            random.Random(42),
        )
        second, _ = failures.select_failures(
            graph, 0, 19, "link", "clustered_random_center", 0, 0.6, 0.3,
            random.Random(42),
        )

        self.assertEqual(first, second)

    def test_clustered_base_model_is_unchanged(self):
        """Das Basismodell bleibt auf den Zielknoten zentriert."""
        graph = nx.star_graph(6)
        rng = random.Random(2)

        failed_edges, _ = failures.select_failures(
            graph, 1, 0, "link", "clustered", 0, 1.0, 0.3, rng
        )

        self.assertEqual(len(failed_edges), graph.degree(0))

    def test_pipeline_exposes_the_new_failure_combinations(self):
        """Pipeline und GUI kennen die neuen Auswahlwerte."""
        for name in (
            "clustered_random_center_link",
            "clustered_random_center_node",
        ):
            self.assertIn(name, pipeline.FAILURE_COMBINATIONS)
            self.assertIn(name, gui.FAILURE_LABELS)

    def test_default_failures_stay_at_the_four_step4_combinations(self):
        """Bestehende Configs ohne `failures` laufen unverändert weiter."""
        self.assertEqual(
            list(pipeline.DEFAULT_FAILURES),
            ["random_link", "random_node", "clustered_link", "clustered_node"],
        )

    def test_configuration_filename_uses_the_new_prefix(self):
        """Die CSV-Dateinamen trennen das neue Modell vom Basismodell."""
        filename = experiment.configuration_filename(
            {
                "failure_type": "link",
                "failure_model": "clustered_random_center",
                "failure_start": 0.6,
            },
            0.3,
        )

        self.assertEqual(
            filename, "algorithms_clustered_random_center_link_fs0.6_fd0.3.csv"
        )


class CompleteGraphTest(unittest.TestCase):
    """Prüft den Graph-Typ `complete_graph`."""

    def test_graph_type_is_registered(self):
        """Der Graph steht in allen drei Registries und damit in der CLI."""
        self.assertIn("complete_graph", experiment.GRAPH_BUILDERS)
        self.assertIn("complete_graph", experiment.GRAPH_PARAMETER_SPECS)
        self.assertIn("complete_graph", experiment.GRAPH_VALIDATORS)
        self.assertIn("complete_graph", experiment.GRAPH_TYPES)

    def test_create_graph_returns_a_complete_graph(self):
        """Der Builder erzeugt tatsächlich K_n."""
        graph = experiment.create_graph("complete_graph", 6, "", 123)

        self.assertEqual(graph.number_of_nodes(), 6)
        self.assertEqual(graph.number_of_edges(), 15)

    def test_dataset_parameter_and_validation_need_no_extra_key(self):
        """Ohne `p` oder `degree` bleibt das Dataset gültig."""
        dataset = {
            "name": "complete_n6",
            "type": "synthetic",
            "graph_type": "complete_graph",
            "nodes": 6,
        }

        graph_param = experiment.graph_parameter_from_dataset(dataset)
        experiment.validate_graph_parameters(
            "complete_graph", 6, graph_param, "complete_n6"
        )

        self.assertEqual(graph_param, "")

    def test_choose_endpoints_falls_back_to_adjacent_pairs(self):
        """In K_n gibt es keine nicht benachbarten Paare mehr."""
        graph = nx.complete_graph(5)

        source, destination = experiment.choose_endpoints(graph, random.Random(1))

        self.assertNotEqual(source, destination)
        self.assertTrue(graph.has_edge(source, destination))

    def test_choose_endpoints_still_prefers_non_adjacent_pairs(self):
        """Bei dünnen Graphen bleibt das Schritt-4-Verhalten erhalten."""
        graph = nx.path_graph(5)

        for seed in range(20):
            source, destination = experiment.choose_endpoints(
                graph, random.Random(seed)
            )
            self.assertFalse(graph.has_edge(source, destination))

    def test_choose_endpoints_raises_without_any_connected_pair(self):
        """Ein Graph ohne Kanten liefert weiterhin einen klaren Fehler."""
        graph = nx.empty_graph(1)

        with self.assertRaises(nx.NetworkXNoPath):
            experiment.choose_endpoints(graph, random.Random(1))

    def test_gui_offers_the_new_graph_type(self):
        """Die GUI benennt den neuen Graph-Typ und baut ein gültiges Dataset."""
        self.assertIn("complete_graph", gui.GRAPH_TYPE_LABELS)

        dataset = gui.build_gui_complete_graph_dataset(8, [1.0, 2.0])

        self.assertEqual(dataset["graph_type"], "complete_graph")
        self.assertEqual(dataset["nodes"], 8)
        self.assertNotIn("p", dataset)


class ExtensionPipelineTest(unittest.TestCase):
    """Prüft alle drei Erweiterungen gemeinsam über die Pipeline."""

    def _config(self, output_root):
        """Baut eine kleine Konfiguration mit allen drei Erweiterungen."""
        return {
            "run_name": "step7_test",
            "output_root": str(output_root),
            "runs": 2,
            "seed": 123,
            "resume": False,
            "algorithms": ["edp_paths", "shortest_path"],
            "failures": [
                "clustered_random_center_link",
                "clustered_random_center_node",
            ],
            "metrics": ["resilience"],
            "datasets": [
                {
                    "name": "complete_n8",
                    "display_name": "Vollständiger Graph n=8",
                    "type": "synthetic",
                    "graph_type": "complete_graph",
                    "nodes": 8,
                    "fail_factors": [1.0],
                    "failure_starts": [0.6],
                    "failure_drop": 0.3,
                }
            ],
        }

    def test_preflight_accepts_the_extended_configuration(self):
        """Preflight validiert Graph, Fehlermodell und Algorithmus."""
        with tempfile.TemporaryDirectory() as temp_dir:
            config_path = Path(temp_dir) / "config.json"
            config_path.write_text(
                json.dumps(self._config(Path(temp_dir) / "Output")),
                encoding="utf-8",
            )

            result = pipeline.run_pipeline(config_path, preflight=True)

        self.assertEqual(len(result["plan"]), 2)
        self.assertIn("jobs=2", result["preflight"])

    def test_small_run_produces_csv_summary_and_manifest(self):
        """Ein kleiner Lauf erzeugt Rohdaten, Summary, Plots und Manifest."""
        with tempfile.TemporaryDirectory() as temp_dir:
            output_root = Path(temp_dir) / "Output"
            config_path = Path(temp_dir) / "config.json"
            config_path.write_text(
                json.dumps(self._config(output_root)), encoding="utf-8"
            )

            result = pipeline.run_pipeline(config_path)

            self.assertEqual(len(result["generated_csvs"]), 2)
            self.assertTrue(Path(result["summary"]).is_file())
            self.assertTrue(Path(result["manifest"]).is_file())
            self.assertTrue(result["plots"])

            raw_files = sorted(
                path.name
                for path in (output_root / "raw" / "complete_n8").glob("*.csv")
            )
            self.assertEqual(
                raw_files,
                [
                    "algorithms_clustered_random_center_link_fs0.6_fd0.3.csv",
                    "algorithms_clustered_random_center_node_fs0.6_fd0.3.csv",
                ],
            )

    def test_repeated_run_is_reproducible(self):
        """Derselbe Seed erzeugt identische Rohdaten."""
        contents = []
        for _ in range(2):
            with tempfile.TemporaryDirectory() as temp_dir:
                output_root = Path(temp_dir) / "Output"
                config_path = Path(temp_dir) / "config.json"
                config_path.write_text(
                    json.dumps(self._config(output_root)), encoding="utf-8"
                )

                pipeline.run_pipeline(config_path, only_experiments=True)

                contents.append(
                    sorted(
                        path.read_text(encoding="utf-8")
                        for path in (output_root / "raw" / "complete_n8").glob("*.csv")
                    )
                )

        self.assertEqual(contents[0], contents[1])


if __name__ == "__main__":
    unittest.main()
